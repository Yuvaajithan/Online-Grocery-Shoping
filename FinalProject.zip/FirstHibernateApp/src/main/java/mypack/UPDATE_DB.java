package mypack;

import java.io.IOException;
import java.util.Iterator;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Restrictions;


public class UPDATE_DB extends HttpServlet {
	private static final long serialVersionUID = 1L;


	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException 
	{
		RequestDispatcher rs;
		
		product p=null;
		
		Configuration cfg = new Configuration();
		Session S = cfg.configure("connect.cfg.xml").buildSessionFactory().openSession();
		
		S.getTransaction().begin();
		
		
		Integer pid = Integer.parseInt(request.getParameter("pid"));			
		String pnm = request.getParameter("pnm");
		int qty = Integer.parseInt(request.getParameter("qty"));
		int price = Integer.parseInt(request.getParameter("price"));
		String mft = request.getParameter("mft");
		
		// HCQL - Hibernate Criteria based Query Language 
		// Criteria , Criterion Interfaces - Restrictions is a class to put validation on primary key fields or any column
		
		
		
		Criteria crit = S.createCriteria(product.class);				
		Criterion c1=Restrictions.eq("prid", pid);

		//price is our pojo class variable

	crit.add(c1); // adding criterion object to criteria class object

	List l = crit.list(); // executing criteria query

	Iterator it = l.iterator();
	while(it.hasNext())
		{
		p = (product)it.next();
		p.setPnm(pnm);
		p.setPrice(price);
		p.setQty(qty);
		p.setManufactuer(mft);
		S.saveOrUpdate(p);		
		break;
		}
		
					
		S.getTransaction().commit();
		
		// with the help of HCQL , fetching all the records
		
		Criteria c= S.createCriteria(product.class);
		
		List L1 = c.list();
								
		request.setAttribute("prdt",L1);
		
		S.close();
		
		rs = request.getServletContext().getRequestDispatcher("/BrowseProduct.jsp");	
		rs.forward(request, response);
		
		
	}

}
