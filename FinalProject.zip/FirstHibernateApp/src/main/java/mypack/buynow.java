package mypack;

import java.io.IOException;
import java.util.Iterator;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.cfg.Configuration;

/**
 * Servlet implementation class buynow
 */
public class buynow extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		 RequestDispatcher rs;
		Integer pid = Integer.parseInt(request.getParameter("id"));
		
		
		
		
		product p=null;
		
		
		
		Configuration cfg = new Configuration();	  
		Session S = cfg.configure("connect.cfg.xml").buildSessionFactory().openSession();
		
		S.getTransaction().begin();
		
		
		// HQL - hibernate query language
		// by using query interface and pass a query
		
		
		  Query qry =S.createQuery(" from product p where p.prid=:VAL "); // named parameter
		  
		  qry.setParameter("VAL", pid);
		  
			List L = qry.list();
			
			
			
			
			Iterator it = L.iterator();
			while(it.hasNext())
				{
				p = (product)it.next();
				break;
				}
		
			request.setAttribute("prdt",L);
			
			
			System.out.println(p+"buy now");
			System.out.println(L+"buy now");
        	
			
			
			
		
		rs = request.getServletContext().getRequestDispatcher("/buy.jsp");	
		rs.forward(request, response);
		
		S.close();
		
		
		
		
		
		
		

		
	}

}