package mypack;

import java.io.IOException;
import java.util.Iterator;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Restrictions;

import mypack.users;
import mypack.cart;
import mypack.product;

import java.lang.*;
/**
 * Servlet implementation class addtocart
 */
public class addtocart extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		 RequestDispatcher rs;
		Integer pid = Integer.parseInt(request.getParameter("id"));
		String	mail = request.getParameter("mai");
		
		
		
		product p=null;
		
		
		
		Configuration cfg = new Configuration();	  
		Session S = cfg.configure("connect.cfg.xml").buildSessionFactory().openSession();
		
		S.getTransaction().begin();
		
		
		// HQL - hibernate query language
		// by using query interface and pass a query
		
		
		  Query qry =S.createQuery(" from product p where p.prid=:VAL "); // named parameter
		  
		  qry.setParameter("VAL", pid);
		  
			List L = qry.list();
			
			Iterator it = L.iterator();
			while(it.hasNext())
				{
				p = (product)it.next();
				break;
				}
		
			request.setAttribute("cartrec",p);
         	
			
			
			 users u = null;
			 
			 
			 Query q1 =S.createQuery("from users u where u.email_id=:VAL"); // named parameter
			  
			 
			  q1.setParameter("VAL", mail);
			  
				List L1 = q1.list();
				
				Iterator it1 = L1.iterator();
				while(it1.hasNext())
					{
					 u = (users)it1.next();
						
					break;
					}
			
				request.setAttribute("cartrec",u);
	    
				
	      System.out.println("u value");
          System.out.println(u);	
		
		
		
		
        cart c = new cart();
		
		c.setPrid(p.prid);
		c.setPnm(p.pnm);
		c.setQty(p.qty);
		c.setPrice(p.price);
		c.setEmail_id(u.email_id);
	  
		System.out.println("cart value");
        System.out.println(c);
		
	     S.save(c);
		
		S.getTransaction().commit();
		
		
		
		
		Query q =S.createQuery("from cart c"); 
		 
		List L3 = q.list();
		
		 System.out.println("cart li l1");
         System.out.println(L3);
									
		request.setAttribute("cartrec",L3);
		
		 System.out.println("enddd");
		 
		 
		 
		/*---------------------*/
		 
		 
		 cart e= null;
		 
		  Query qw =S.createQuery(" from cart e where e.email_id=:VAL "); // named parameter
		  
		  qw.setParameter("VAL", mail);
		  
		  List L4 = qw.list();
		  
		  
			
			
			
		request.setAttribute("cartrc",L4);
		
		
		  
		
		rs = request.getServletContext().getRequestDispatcher("/cart.jsp");	
		rs.forward(request, response);
		
		S.close();
		
		
		
		
		
		
		

		
	}

}