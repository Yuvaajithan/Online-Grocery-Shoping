package mypack;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Restrictions;

public class delete extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    Integer pid = Integer.parseInt(request.getParameter("id"));
		
		Configuration cfg = new Configuration();
		Session S = cfg.configure("connect.cfg.xml").buildSessionFactory().openSession();
		cart q= null;
		S.getTransaction().begin();
		
		
		Criteria crit = S.createCriteria(cart.class);				
		Criterion c1=Restrictions.eq("prid", pid);
	
		
		crit.add(c1); // adding criterion object to criteria class object

		List l = crit.list(); // executing criteria query

		Iterator it = l.iterator();
		while(it.hasNext())
			{
			q = (cart)it.next();
			S.delete(q);			
			break;
			}
		
		S.getTransaction().commit();
		
		// with the help of HCQL , fetching all the records
		
		Criteria c= S.createCriteria(cart.class);
		
		List L1 = c.list();
								
		request.setAttribute("cartrc",L1);
		System.out.println(L1);
		S.close();
		
		RequestDispatcher rs;
		rs = request.getServletContext().getRequestDispatcher("/cart.jsp");	
		rs.forward(request, response);
		 
		
	}

}
