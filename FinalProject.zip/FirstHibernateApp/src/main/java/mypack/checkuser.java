package mypack;

import java.io.*;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;


public class checkuser extends HttpServlet 
{
	private static final long serialVersionUID = 1L;

	
	protected void service(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException 
	{
		 int flag=0;
		 RequestDispatcher rs;
	
	//response.setContentType("text/html");
	//PrintWriter pw = response.getWriter();
	

	/* Configuration cfg = new Configuration();
	 cfg.configure("connect.cfg.xml");	 	
	 SessionFactory F = cfg.buildSessionFactory();     
	 Session S = F.openSession();
	 */
	
	Configuration cfg = new Configuration();	  
	Session S = cfg.configure("connect.cfg.xml").buildSessionFactory().openSession();
	

  Query qry =S.createQuery("from users u where u.email_id=:VAL"); // named parameter
 
  qry.setParameter("VAL", request.getParameter("mail"));
  
	List L = qry.list();
	
	Iterator it = L.iterator();
	while(it.hasNext())
		{
		users u = (users)it.next();
		flag = 1;	
		break;
		}

	if(flag == 1)
	{
	    
		    
		    
			Query q =S.createQuery("from product p"); 
		 				 
			List L1 = q.list();
										
			request.setAttribute("prdt",L1);
			request.setAttribute("usrnm",L);
			
			rs = request.getServletContext().getRequestDispatcher("/BrowseProduct.jsp");
			
			
			
			
	        System.out.println("browse");
			System.out.println(L1);
			

						
	}
	else
	{
		rs = request.getServletContext().getRequestDispatcher("/login.jsp");		
	}
	
	
	rs.forward(request, response);
	  	
	S.close();
	//F.close();
					
	}

}
