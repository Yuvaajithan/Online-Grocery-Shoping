package mypack;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import java.lang.*;

@Entity
@Table(name="cart")
public class cart 
{
	@Id	
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int prid;

	@Column(name="pnm")
	public String pnm;
	
	@Column(name="qty")
	private int qty;
	
	@Column(name="price")
	private int price;	
	
	@Column(name="email_id")
	public String email_id;
	
	
			
	public String toString()
	{
		return "\nProduct Id: "+getPrid()+"\nProduct Name : "+getPnm()+"\nQuantity : "+getQty()+"\nPrice: "+getPrice()+"\nMail: "+getEmail_id();		
	}
	
	
	public int getPrid() {
		return prid;
	}
	public void setPrid(int prid) {
		this.prid = prid;
	}
	public String getPnm() {
		return pnm;		
	}
	public void setPnm(String pnm) {
		this.pnm = pnm;
	}
	public int getQty() {
		return qty;
	}
	public void setQty(int qty) {
		this.qty = qty;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	
	public String getEmail_id() {
		return email_id;		
	}
	public void setEmail_id(String email_id) {
		this.email_id = email_id;
	}

		
}

