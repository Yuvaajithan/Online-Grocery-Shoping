package mypack;

import java.io.IOException;
import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.cfg.Configuration;



/**
 * Servlet implementation class CALLNAMEDQUERY
 */
public class CALLNAMEDQUERY extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
RequestDispatcher rs;
		
		product p=null;
		
		Configuration cfg = new Configuration();
		Session S = cfg.configure("connect.cfg.xml").buildSessionFactory().openSession();
		
		
		S.getTransaction().begin();
		
		
		 Query query1 = S.getNamedQuery("getbyid")
                 .setInteger("id", 22)  ;              
		 	
				 	
		 Query query2 = S.getNamedQuery("getbyqty")
                 .setInteger("ty", 50)  ;              
		 		 
		 		 			 			
			request.setAttribute("byid",query1.list());
					
			request.setAttribute("byqty",query2.list());
			
		/*	Query query3 = S.getNamedQuery("callgetproductnamesbyprice").setParameter("price",700);
			List<ProductNames> nms = query3.list();
			
			request.setAttribute("allnamesbyprice",nms);*/
			
			
			
		 S.getTransaction().commit();
		 S.close();
		 
			rs = request.getServletContext().getRequestDispatcher("/namedquery.jsp");	
			rs.forward(request, response);
		
		
		
	}




	

}
